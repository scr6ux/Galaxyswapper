﻿using System.IO;

namespace Galaxy_Swapper_v2.Workspace.Generation.Formats
{
    public class StreamData
    {
        public string Path { get; set; }
        public string Name { get; set; }
        public Stream Stream { get; set; }
    }
}
