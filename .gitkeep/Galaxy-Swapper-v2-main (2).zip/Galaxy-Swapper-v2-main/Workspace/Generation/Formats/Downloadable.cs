﻿namespace Galaxy_Swapper_v2.Workspace.Generation.Formats
{
    public class Downloadable
    {
        public string Pak;
        public string Sig;
        public string Ucas;
        public string Utoc;
        public string Zip;
    }
}