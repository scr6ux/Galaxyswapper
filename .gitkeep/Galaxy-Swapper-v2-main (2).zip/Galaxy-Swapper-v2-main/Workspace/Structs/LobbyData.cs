﻿namespace Galaxy_Swapper_v2.Workspace.Structs
{
    public class LobbyData
    {
        public string Preview { get; set; }
        public string Download { get; set; }
        public string Name { get; set; }
        public bool IsNsfw = false;
    }
}
