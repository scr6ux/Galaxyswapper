﻿namespace Galaxy_Swapper_v2.Workspace.Structs
{
    public class Social
    {
        public string Icon = null!;
        public string Header = null!;
        public string URL = null!;
    }
}