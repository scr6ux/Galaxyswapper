﻿namespace Galaxy_Swapper_v2.Workspace.CProvider.Objects
{
    public enum CompressionMethod
    {
        None = 0,
        Zlib = 1,
        Gzip = 2, //???
        Custom = 3,
        Oodle = 4,
        LZ4,
        Zstd,
        Unknown
    }
}