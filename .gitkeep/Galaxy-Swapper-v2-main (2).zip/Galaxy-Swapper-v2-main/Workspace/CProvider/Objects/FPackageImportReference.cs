﻿namespace Galaxy_Swapper_v2.Workspace.CProvider.Objects
{
    public struct FPackageImportReference
    {
        public uint ImportedPackageIndex;
        public uint ImportedPublicExportHashIndex;
    }
}